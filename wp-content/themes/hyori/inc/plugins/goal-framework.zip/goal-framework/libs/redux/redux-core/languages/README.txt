Translations have moved to
https://translate.wordpress.org/projects/wp-plugins/redux-framework

Thank you for your contribution.
